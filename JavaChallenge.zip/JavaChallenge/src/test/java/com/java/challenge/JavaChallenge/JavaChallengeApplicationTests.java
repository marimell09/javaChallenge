package com.java.challenge.JavaChallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
